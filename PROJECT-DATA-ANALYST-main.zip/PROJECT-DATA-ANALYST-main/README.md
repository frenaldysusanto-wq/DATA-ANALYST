[![License](https://img.shields.io/badge/license-MIT-informational.svg)]()
[![Contributions Welcome](https://img.shields.io/badge/Contributions-Welcome-brightgreen.svg?style=flat&logo=github&logoColor=white)](https://github.com/username/repo/issues)
[![Python](https://img.shields.io/badge/Python-3.10-3776AB.svg?style=flat&logo=python&logoColor=yellow)](https://www.python.org/)
[![Google Colab](https://img.shields.io/badge/Google%20Colab-Notebook-orange.svg?logo=google-colab&logoColor=white)](https://colab.research.google.com/)
[![Jupyter](https://img.shields.io/badge/Jupyter-Notebook-F37626.svg?style=flat&logo=jupyter&logoColor=white)](https://jupyter.org/)
![Pandas](https://img.shields.io/badge/Pandas-2.0%2B-green)
![NumPy](https://img.shields.io/badge/NumPy-1.24%2B-orange)
![Matplotlib](https://img.shields.io/badge/Matplotlib-3.7%2B-11557c)
![Seaborn](https://img.shields.io/badge/Seaborn-0.12%2B-4c72b0)
![Scikit-Learn](https://img.shields.io/badge/Scikit--Learn-Machine%20Learning-F7931E?labelColor=1E293B&logo=scikitlearn&logoColor=white)
![Looker Studio](https://img.shields.io/badge/Looker%20Studio-4285F4?logo=google&logoColor=white)
[![MySQL Version](https://img.shields.io/badge/MySQL-8.0-blue.svg)](https://www.mysql.com/)
[![Database Tool](https://img.shields.io/badge/DBeaver-Latest-orange.svg)](https://dbeaver.io/)
![Google Sheets](https://img.shields.io/badge/Google%20Sheets-Advanced-34A853?labelColor=1E293B&logo=googlesheets&logoColor=white)
![Problem Solving](https://img.shields.io/badge/Problem%20Solving-Framework-F59E0B?labelColor=1E293B&logo=target&logoColor=white)
![Statistics](https://img.shields.io/badge/Statistics-Expert-8B5CF6?labelColor=1E293B&logo=scipy&logoColor=white)
![EDA](https://img.shields.io/badge/EDA-Exploratory-EC4899?labelColor=1E293B&logo=plotly&logoColor=white)
![Statistics](https://img.shields.io/badge/Statistics-Expert-8B5CF6?labelColor=1E293B&logo=scipy&logoColor=white)
![Data Cleaning](https://img.shields.io/badge/Data%20Cleaning-Advanced-10B981?labelColor=1E293B&logo=pandas&logoColor=white)
![Metrics](https://img.shields.io/badge/Metrics-Analytics-3B82F6?labelColor=1E293B&logo=googleanalytics&logoColor=white)
<p align="left">
  <img src="poster-design-data-analyst.jpg" alt="data-analyst-poster" width="925">
</p>
<p align="center">
  <a href="https://www.linkedin.com/in/harisariefkamis">
    <img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn">
  </a>
  <a href="https://github.com/harrisariefkamis">
    <img src="https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub">
  </a>
  <a href="https://bit.ly/WebsitePortofolioDataAnalyst">
    <img src="https://img.shields.io/badge/Portfolio-4CAF50?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Portfolio">
  </a>


</p>
<p align="center">
  <strong>“Data is a tree of life that keeps taking root, the foundation for the technology ecosystem of the future.” 
</p>
<p align="center">
  <strong>harryyss__Data Enthusiast
</p>



        
## About Repository

Repositori ini adalah **project pembelajaran Data Analyst** yang berisi roadmap belajar terstruktur untuk membangun kemampuan dasar hingga menengah dalam analisis data, SQL, Python, visualisasi, dan persiapan karier.

> *"Data is the new oil."* Namun minyak mentah tidak bernilai tanpa **curiosity** untuk mengeksplorasi, **critical thinking** untuk memvalidasi, dan **storytelling** untuk mengomunikasikan insight-nya.

Saya mendorong algoritma pembelajaran ini dengan pendekatan method yang sedikit berbeda di mana **data curiosity** menjadi kompas utama, **analytical thinking** menjadi mesin pemrosesnya, dan **problem solving** menjadi tujuan akhirnya. Setiap temuan divalidasi melalui **data-driven decision making** yang rigoris, dengan **framework** yang terstruktur dan **workflow** yang repetabel.

Tujuan besarnya sederhana: membentuk Anda menjadi **problem solver** sejati bukan sekadar pengguna tools, tetapi analis yang mampu membedah masalah bisnis dari akar, merancang **arsitektur** analisis yang tepat, dan membangun **infrastruktur** data yang scalable untuk pengambilan keputusan jangka panjang.

### Fokus Pembelajaran

- **Descriptive & Inferential Statistics:** fondasi statistik untuk membaca pola dan menarik kesimpulan
- **SQL for Business Analytics:** dari basic clause hingga `window functions,``CTE,`dan `query optimization`
- **Python Data Stack**,**NumPy** & **Pandas** untuk `data wrangling,` `feature engineering,` dan `exploratory data analysis (EDA)`
- **Data Cleaning & Preprocessing:** menangani `missing values,` `outliers,` `duplicates,` dan `data normalization`
- **Data Visualization & Storytelling:** membangun `dashboard interaktif` dengan `Looker Studio,` `Matplotlib,` dan `Seaborn` untuk menyampaikan `actionable insights`
- **Exploratory Data Analysis (EDA)** mengembangkan `data intuition` melalui `hypothesis testing` dan `pattern discovery`
- **Career & Technical Interview Preparation**,*case study interview* `SQL technical interview` *CV review*, dan *behavioral interview*

### Framework & Workflow Belajar

Setiap modul dirancang mengikuti **framework** pembelajaran yang konsisten:

1. **Understand the Problem** membangun *problem framing* & *business acumen*
2. **Explore with Curiosity** melatih `data curiosity` dan *analytical thinking*
3. **Build the Solution** merancang *arsitektur* analisis & `workflow` yang repetabel
4. **Validate & Iterate** menguji temuan dengan *hypothesis testing* dan *evidence*
5. **Communicate the Insight** mengasah `data storytelling` dan *actionable insights*

Dengan **workflow** ini, Anda dan tim dapat mengambil **data-driven decisions** serta merumuskan `data-driven policies` untuk mengelola suatu project bukan berdasarkan asumsi, melainkan berdasarkan **evidence**, **metrics**, dan **insight** yang terukur. **Curiosity** bukan sekadar sifat, tetapi **core skill** seorang Data Analyst profesional. `Analytical thinking` bukan bakat, melainkan kebiasaan yang dilatih. Dan **problem solving** bukan tujuan akhir melainkan **mindset** yang terus diasah.

> **Filosofi belajar aku:** *"learn algorithm the Plants"* Setiap modul dirancang untuk melatih **analytical curiosity**, **problem framing**, dan **business acumen** tiga pilar utama untuk menjadi **insight-driven analyst** yang mampu membangun **arsitektur** dan **infrastruktur** analitik yang berdampak.

## Tech Stack:

#### Google Cloud & Analytics

<p>
  <a href="https://colab.research.google.com"><img src="https://colab.research.google.com/assets/colab-badge.svg" alt="Google Colab" height="28"></a>
  <a href="https://cloud.google.com/bigquery"><img src="https://www.gstatic.com/images/branding/gcpiconscolors/bigquery/v1/32px.svg" alt="BigQuery" height="32"></a>
  <a href="https://lookerstudio.google.com"><img src="https://www.gstatic.com/analytics-lego/svg/ic_looker_studio.svg" alt="Looker Studio" height="32"></a>
  <a href="https://sheets.google.com"><img src="https://ssl.gstatic.com/docs/common/product/sheets_app_icon1.png" alt="Google Sheets" height="32"></a>
</p>

#### Python Data Stack
<p align="left">
  <a href="https://pandas.pydata.org"><img src="https://pandas.pydata.org/static/img/pandas.svg" alt="Pandas" height="50"></a>
  <a href="https://numpy.org"><img src="https://raw.githubusercontent.com/numpy/numpy/main/branding/logo/primary/numpylogo.svg" alt="NumPy" height="50"></a>
  <a href="https://seaborn.pydata.org"><img src="https://seaborn.pydata.org/_images/logo-wide-lightbg.svg" alt="Seaborn" height="40"></a>
  <a href="https://scikit-learn.org"><img src="https://raw.githubusercontent.com/scikit-learn/scikit-learn/main/doc/logos/scikit-learn-logo.svg" alt="scikit-learn" height="90"></a>
  <a href="assets/matplotlib.svg" download>
  <img src="https://upload.wikimedia.org/wikipedia/commons/8/84/Matplotlib_icon.svg" alt="Matplotlib" height="32">
</p>

#### Database
[![MySQL](https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white)](https://www.mysql.com/)
[![MySQL Workbench](https://img.shields.io/badge/MySQL_Workbench-00758F?style=for-the-badge&logo=mysql&logoColor=white)](https://www.mysql.com/products/workbench/)
[![DBeaver](https://img.shields.io/badge/DBeaver-372923?style=for-the-badge&logo=dbeaver&logoColor=white)](https://dbeaver.io/)

#### Google Spreadsheet
[![Google Sheets](https://img.shields.io/badge/Google_Sheets-34A853?style=for-the-badge&logo=googlesheets&logoColor=white)](https://sheets.google.com)

#### IDE & Development
![VS Code](https://img.shields.io/badge/VS_Code-007ACC?style=for-the-badge&logo=visualstudiocode&logoColor=white)
![Jupyter](https://img.shields.io/badge/Jupyter-F37626?style=for-the-badge&logo=jupyter&logoColor=white)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)

#### Mathematics & Statistics Dasar
![Statistics](https://img.shields.io/badge/Statistics-009688?style=for-the-badge&logo=scipy&logoColor=white)
![Linear Algebra](https://img.shields.io/badge/Linear_Algebra-0078D4?style=for-the-badge&logo=wolframmathematica&logoColor=white)
![Probability](https://img.shields.io/badge/Probability-E91E63?style=for-the-badge&logo=mathoverflow&logoColor=white)

## Summary Stack
```
PROJECT-DATA-ANALYST/
├── 01-intro/
├── 02-data-wrangling/
├── 03-eda/
├── 04-sql/
├── 05-visualization/
├── 06-data-cleaning/
│   └── notebooks/
│       └── 06_data_cleaning_beginner.ipynb
├── 07-machine-learning/
└── assets/
    ├── matplotlib.svg
    ├── postgresql.svg
    ├── dbeaver.svg
    ├── excel.svg
    └── vscode.svg
```

---

## Outline Project

#### Data Cleaning

| Notebook | Deskripsi | Buka |
|---|---|---|
| `06_data_cleaning_beginner.ipynb` | Teknik dasar data cleaning: handling missing values, duplikasi, dan outlier | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/harrisariefkamis/PROJECT-DATA-ANALYST/blob/main/06-data-cleaning/notebooks/06_data_cleaning_beginner.ipynb) |

#### Exploratory Data Analysis (EDA)

| Notebook | Deskripsi | Buka |
|---|---|---|
| `03_eda_intro.ipynb` | Eksplorasi dataset & statistik deskriptif | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/harrisariefkamis/PROJECT-DATA-ANALYST/blob/main/03-eda/notebooks/03_eda_intro.ipynb) |

#### SQL

| Notebook | Deskripsi | Buka |
|---|---|---|
| `04_sql_basic.ipynb` | Query dasar SQL dengan MySQL & PostgreSQL | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/harrisariefkamis/PROJECT-DATA-ANALYST/blob/main/04-sql/notebooks/04_sql_basic.ipynb) |

#### Machine Learning

| Notebook | Deskripsi | Buka |
|---|---|---|
| `07_ml_intro.ipynb` | Pengenalan machine learning dengan scikit-learn | [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/harrisariefkamis/PROJECT-DATA-ANALYST/blob/main/07-machine-learning/notebooks/07_ml_intro.ipynb) |

> 💡 **Tips:** Ganti `USERNAME`, `REPO`, dan `PATH/KE/NOTEBOOK.ipynb` sesuai struktur repositori Anda.

---

## Cara Menjalankan IDE

#### Opsi 1 Google Colab (Direkomendasikan)

Klik **Open in Colab** pada tabel project di atas. Notebook akan terbuka langsung di browser tanpa perlu instalasi.!!!

#### Opsi 2 Lokal (VS Code / Jupyter)

```bash
# Clone repositori
git clone https://github.com/harrisariefkamis/PROJECT-DATA-ANALYST.git
cd PROJECT-DATA-ANALYST

# Buat virtual environment
python -m venv venv
source venv/bin/activate    # Linux/macOS
# venv\Scripts\activate     # Windows

# Install dependencies
pip install pandas numpy matplotlib seaborn scikit-learn jupyter

# Jalankan Jupyter
jupyter notebook
```

---

## Tujuan Pembelajaran
Repositori ini dirancang untuk membantu anda:
- memahami dasar analisis data dan metrik bisnis;
- menguasai SQL untuk analisis data dan kasus wawancara;
- menggunakan Python untuk pemrosesan data dan studi kasus;
- membangun visualisasi yang informatif;
- mempersiapkan CV, interview, dan portofolio data analysis.

## Temuan Utama (Guideline & Overview)

- 01-on-boarding — [README](./01-on-boarding/README.md)
- 02-career-and-hr — [README](./02-career-and-hr/README.md)
- 03-intro-data-analysis — [README](./03-intro-data-analysis/README.md)
- 04-statistics — [README](./04-statistics/README.md)
- 05-metrics — [README](./05-metrics/README.md)
- 06-data-cleaning — [README](./06-data-cleaning/README.md)
- 07-sql-basic-1 — [README](./07-sql-basic-1/README.md)
- 08-sql-basic-2 — [README](./08-sql-basic-2/README.md)
- 09-sql-basic-3 — [README](./09-sql-basic-3/README.md)
- 10-sql-advanced — [README](./10-sql-advanced/README.md)
- 11-sql-interview-cases — [README](./11-sql-interview-cases/README.md)
- 12-python-basic-project — [README](./12-python-basic-project/README.md)
- 13-python-numpy-pandas — [README](./13-python-numpy-pandas/README.md)
- 14-python-study-cases — [README](./14-python-study-cases/README.md)
- 15-data-viz-basic — [README](./15-data-viz-basic/README.md)
- 16-data-studio — [README](./16-data-studio/README.md)
- 17-projects-and-interviews — [README](./17-projects-and-interviews/README.md)

## Struktur Repository

```text
PROJECT-DATA-ANALYST/
├── README.md
├── CONTRIBUTING.md
├── 01-on-boarding/
│   └── README.md
├── 02-career-and-hr/
│   └── README.md
├── 03-intro-data-analysis/
│   └── README.md
├── 04-statistics/
│   └── README.md
├── 05-metrics/
│   └── README.md
├── 06-data-cleaning/
│   └── README.md
├── 07-sql-basic-1/
│   └── README.md
├── 08-sql-basic-2/
│   └── README.md
├── 09-sql-basic-3/
│   └── README.md
├── 10-sql-advanced/
│   └── README.md
├── 11-sql-interview-cases/
│   └── README.md
├── 12-python-basic-project/
│   └── README.md
├── 13-python-numpy-pandas/
│   └── README.md
├── 14-python-study-cases/
│   └── README.md
├── 15-data-viz-basic/
│   └── README.md
├── 16-data-studio/
│   └── README.md
├── 17-projects-and-interviews/
│   └── README.md
├── datasets/
├── notebooks/
├── exercises/
├── solutions/
└── .github/
    └── ISSUE_TEMPLATE.md
```

## Roadmaps Modul

1. On Boarding
2. Secure Your First Data Analyst Job
3. Intro to Data Analysis
4. Basic Statistics
5. The Metrics: Measure What Matters
6. Data Formatting dan Cleansing
7. SQL Basic 1: Basic Clause
8. SQL Basic 2
9. SQL Basic 3: Analyzing Business Data
10. SQL For Data Analysis 4
11. SQL For Data Analysis 5 / SQL Technical Interview Case Studies
12. Data Analysis with Python 1: Basic Python + Project 1
13. Data Analysis with Python 2: Work with Numpy & Pandas Study Cases
14. Data Analysis with Python 3: Study Cases
15. Data Visualisation 1: Basic Data Viz + Project 2
16. Data Visualisation 2: Google Data Studio
17. Career Class: HR CV Review + Interview

## Urutan Belajar yang harus diselesaikan
- Pemula: mulai dari modul 1 sampai 6
- Setelah itu: SQL dari modul 7 sampai 11
- Lanjut: Python dari modul 12 sampai 14
- Setelah itu: visualisasi dan dashboard dari modul 15 sampai 16
- Terakhir: modul 17 untuk persiapan karier

## Notes (Catatan & Summary)
Setiap folder modul dapat berisi:
- README.md: deskripsi tujuan dan materi
- datasets/: file contoh data
- notebooks/: notebook latihan
- exercises/: tugas dan soal
- solutions/: jawaban referensi
- slides/: materi presentasi jika diperlukan

## Kontribusi
Silakan baca [CONTRIBUTING.md](CONTRIBUTING.md) untuk pedoman pengembangan repositori.

## Lisensi
Copyright © {2026} Haris Arief Kamis

All rights reserved.

Konten dalam repositori ini dipublikasikan untuk tujuan pembelajaran dan portofolio. Materi, kode, dataset, notebook, dan dokumen lain di repositori ini tidak boleh disalin, disebarluaskan, atau digunakan ulang (termasuk untuk tujuan komersial) tanpa izin tertulis dari pemilik hak cipta. Untuk permintaan lisensi atau kolaborasi, silakan hubungi: https://www.linkedin.com/in/harisariefkamis.

Pelanggaran terhadap ketentuan ini dapat dikenai tindakan perdata dan/atau pidana menurut peraturan perundang‑undangan yang berlaku di Indonesia, termasuk tetapi tidak terbatas pada Undang‑Undang Nomor 11 Tahun 2008 tentang Informasi dan Transaksi Elektronik sebagaimana telah diubah dengan Undang‑Undang Nomor 19 Tahun 2016 (UU ITE) dan ketentuan hak cipta di bawah Undang‑Undang Hak Cipta. Pemilik hak berhak menuntut penghapusan/penarikan konten yang melanggar dari platform pihak ketiga dan/atau menempuh upaya hukum sesuai hukum yang berlaku.

#### Contact Saya:
```python
print ("Haris Arief Kamis")
print ("Data Enthusiast / Data Analyst")
print ("ID.Java, Kota Bogor, 16144")
```
#### Hubungi Saya:

Untuk kerja Kolaborasi & Konsultasi, Klik tautan media sosial dibawah ini.!

<p>
  <a href="https://www.linkedin.com/in/harisariefkamis">
    <img src="https://img.shields.io/badge/LinkedIn-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white" alt="LinkedIn">
  </a>
  <a href="https://github.com/harrisariefkamis">
    <img src="https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub">
  </a>
  <a href="https://bit.ly/WebsitePortofolioDataAnalyst">
    <img src="https://img.shields.io/badge/Portfolio-4CAF50?style=for-the-badge&logo=googlechrome&logoColor=white" alt="Portfolio">
  </a>
</p>

  <p align="center">
  <sub>⭐ Thanks For Everthing,Jika repositori ini bermanfaat, jangan lupa beri bintang!⭐</sub>
</p>







  <p align="center">
  <sub>Copyright © {2026} Haris Arief Kamis
  <p align="center">
  <sub>All rights reserved.</sub>
</p>
